import React from 'react';
import {render} from 'react-dom';
import App from './Main';

render(
    <App />,
    document.getElementById('root')
);